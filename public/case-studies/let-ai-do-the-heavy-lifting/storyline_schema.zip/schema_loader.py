#!/usr/bin/env python3
"""
Small loader utility that detects Storyline version from a project folder and
loads the matching schema JSON (keeps v3.104 and v3.105 available).

Usage:
  python schema_loader.py [--path PATH_TO_STORY_FOLDER]

If no path provided, the script expects to run in the project root where
`story/story.xml` exists (or you can pass the folder containing `story/`).

This script is dependency-free (uses stdlib xml.etree and json).
"""
import argparse
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET

SCHEMA_MAP = {
    "3.104": "schema_v3.104.35448.0.json",
    "3.105": "schema_v3.105.35604.0.json"
}

MASTER_SCHEMA = 'schema_master.json'

def detect_version_from_psmdcp(core_dir: Path):
    # Look for any .psmdcp and try to parse <version>...</version>
    for p in core_dir.glob("*.psmdcp"):
        try:
            text = p.read_text(encoding='utf-8')
        except Exception:
            continue
        m = re.search(r"<version>([^<]+)</version>", text)
        if m:
            ver = m.group(1).strip()
            if ver.startswith("3.105"):
                return "3.105"
            if ver.startswith("3.104"):
                return "3.104"
    return None


def detect_version_from_story(story_xml: Path):
    try:
        root = ET.parse(story_xml).getroot()
    except Exception:
        return None
    # Check for attributes observed in v3.105
    attrs = root.attrib
    markers = [
        'UseNewAutofitDefaults',
        'UseNewFontScaling',
        'autofitUpgraded',
        'defaultGenerateCC',
        'reviewItemLinkingUpgraded',
        'renderingEngineType'
    ]
    for k in markers:
        if k in attrs:
            return '3.105'
    # fallback: no markers found -> assume older 3.104
    return '3.104'


def find_schema(project_root: Path):
    schemas_dir = project_root / 'schemas'
    if not schemas_dir.exists():
        raise FileNotFoundError(f"Schemas directory not found: {schemas_dir}")
    # Prefer a master schema file if present. The master can contain embedded
    # per-version schema content or point to external files via file_reference.
    master_path = schemas_dir / MASTER_SCHEMA
    if master_path.exists():
        try:
            master = json.loads(master_path.read_text(encoding='utf-8'))
        except Exception:
            master = None

        # detect version (psmdcp preferred, then story.xml)
        core_dir = project_root / 'package' / 'services' / 'metadata' / 'core-properties'
        v = None
        if core_dir.exists():
            v = detect_version_from_psmdcp(core_dir)
        if not v:
            story_xml = project_root / 'story' / 'story.xml'
            if story_xml.exists():
                v = detect_version_from_story(story_xml)

        # Default fallback to latest known schema key
        if not v:
            # pick the max key (string compare works for '3.104'/'3.105')
            v = sorted(master.get('schemas', {}).keys())[-1] if master and master.get('schemas') else '3.105'

        # If embedded content exists under that key, return a synthetic path-like object
        # by writing the embedded content to a temp file is possible, but here we prefer
        # to return the external referenced filename if available, otherwise the master.
        entry = master.get('schemas', {}).get(v) if master else None
        if entry:
            # If file_reference exists and file is present, use it
            ref = entry.get('file_reference')
            if ref:
                candidate = schemas_dir / ref
                if candidate.exists():
                    return candidate
            # Otherwise fall back to the master file itself so loader can inspect embedded content
            return master_path

    # No master found or it didn't resolve a version -> fallback to previous behavior
    core_dir = project_root / 'package' / 'services' / 'metadata' / 'core-properties'
    if core_dir.exists():
        v = detect_version_from_psmdcp(core_dir)
        if v:
            return schemas_dir / SCHEMA_MAP[v]

    story_xml = project_root / 'story' / 'story.xml'
    if story_xml.exists():
        v = detect_version_from_story(story_xml)
        if v:
            return schemas_dir / SCHEMA_MAP[v]

    # Last resort: pick latest schema (v3.105)
    return schemas_dir / SCHEMA_MAP['3.105']


def load_schema(schema_path: Path):
    return json.loads(schema_path.read_text(encoding='utf-8'))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--path', '-p', help='Path to project root (contains story/)', default='.')
    args = p.parse_args()

    project_root = Path(args.path).resolve()
    try:
        schema_file = find_schema(project_root)
    except FileNotFoundError as e:
        print('Error:', e)
        return

    if not schema_file.exists():
        print('Schema file not found:', schema_file)
        return

    schema = load_schema(schema_file)
    print('Selected schema:', schema_file.name)
    print('Schema story version:', schema.get('storyline_version'))

    # Print a short snippet to help app authors
    ct = schema.get('content_types', {}).get('slide_title', {})
    print('\nslide_title extraction priorities:')
    for item in ct.get('priority', []):
        print(' -', item.get('type'), item.get('expr') if 'expr' in item else item.get('method'))

    # Example: return on stdout a small mapping that an app can read
    output = {
        'selected_schema': schema_file.name,
        'storyline_version': schema.get('storyline_version'),
        'slide_title_patterns': [item.get('expr') for item in ct.get('priority', []) if item.get('expr')]
    }
    print('\nJSON summary:')
    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()
