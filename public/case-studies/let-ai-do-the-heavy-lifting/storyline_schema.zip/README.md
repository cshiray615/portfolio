Schemas and loader for Storyline 3.x

Files created:
- schema_v3.104.35448.0.json  - original schema for Storyline v3.104
- schema_v3.105.35604.0.json  - updated schema for Storyline v3.105
- schema_loader.py            - helper utility to detect project Storyline version and select the correct schema

How it works
1. The loader looks for package/core-properties (.psmdcp) files and tries to read a <version> tag. If it sees a 3.105 marker it selects the v3.105 schema.
2. If the package meta isn't available, it parses `story/story.xml` and looks for new attributes introduced in v3.105 (e.g., UseNewAutofitDefaults, UseNewFontScaling, autofitUpgraded, defaultGenerateCC, renderingEngineType). If any are present it selects v3.105, otherwise it falls back to v3.104.
3. The loader prints the selected schema name and a short JSON summary useful for downstream apps.

Usage
Run the loader from the project root (the folder that contains `story/`) or pass --path:

```powershell
python .\schemas\schema_loader.py --path .
```

Next steps / Integration tips
- Integrate the loader into your extraction apps: call it to pick a schema before running slide extraction.
- Prefer using `lxml` when implementing XPath queries from these schemas: ElementTree doesn't support starts-with() and contains() and the schemas include fallbacks when using ET.
- If you want, I can wire the loader into a small extraction demo that runs title/body/notes extraction for the first slide.
